@extends('layouts.web')

@section('content')
<div class="mt-44 lg:mt-28">
    <section class="bg-light contentSection">
        <div class="grid grid-cols-1 lg:px-20 mx-4 my-4" bis_skin_checked="1">
            <h1 class="a1g a1A dark:aI text-4xl md:text-5xl text-center sm:text-left">
                {{ $category->name }}
            </h1>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:px-20 mx-4">
            <div class="lg:col-span-8 bg-white side-panel">
                <div class="container mx-auto grid sm:grid-cols-4 xl:grid-cols-2 gap-y-10">
                    @if (count($blogs) > 0)
                        @foreach ($blogs as $blog)
                            <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 mx-2">
                                    <div class="flex flex-col h-full max-w-lg mx-auto rounded-lg bg-dark-lite bg-opacity-[10%] dark:bg-opacity-50">
                                        <a href="{{ route('blogs.show', $blog->slug) }}" class="block bg-gray-50 rounded-lg rounded-b-none">
                                            <img class="rounded-t-lg object-cover h-48 w-96 mx-auto"
                                                src="{{ url(config('app.storage_path') . $blog->image_path) }}"
                                                alt="thumbnail" loading="lazy" />
                                        </a>
                                        <div class="flex justify-end -mt-4 px-4">
                                            <span class=" flex h-min space-x-1 items-center rounded-full text-gray-400 bg-gray-800 py-1 px-2 text-xs font-medium">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-100" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                                <p class="text-gray-100 font-semibold text-xs">
                                                    {{ getEstimateReadingTime($blog->body) }}
                                                </p>
                                            </span>
                                        </div>
                                        <div class="py-2 px-4">
                                            <h2
                                                class="text-xl leading-6 tracking-wide text-color text-hover font-semibold cursor-pointer">
                                                <a href="{{ route('blogs.show', $blog->slug) }}">
                                                    {{ Str::limit($blog->title, 50, '...') }}
                                                </a>
                                            </h2>
                                        </div>
                                        <div class="flex flex-row items-end h-full w-full px-4 mt-4">
                                            <div class="flex border-t border-gray-700 w-full py-4">
                                                <div class="flex items-center space-x-3 border-gray-700 w-full">
                                                    <img class="object-cover w-8 h-8 border-2 border-gray-300 dark:border-white rounded-full"
                                                        src="{{ asset('imgs/icons/user.png') }}"
                                                        alt="profile users" loading="lazy" />
                                                    <div class="">
                                                        <p class="text-sm font-semibold tracking-wide  text-color">
                                                            {{ $blog->user->name }}
                                                        </p>
                                                        <p class="text-xs font-light tracking-wider  text-color">
                                                            {{ showDate($blog->created_at) }}
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>

                        @endforeach                
                    @else
                        <div class="">
                            <p class="py-4 mx-auto md:mx-0 heading-secondary text-dark-lite dark:text-white">
                                No Blog found
                            </p>
                        </div>
                    @endif
                </div>  
                <div class="container mx-auto mt-3">
                    <div class="mx-auto max-w-sm py-4 text-dark-lite dark:text-white">
                    </div>
                </div>          
            </div>
            <div class="lg:col-span-4 ">
                <div class="col-lg-4">
                    <div class="Block">
                        <!--<div class="side-panel relative mb-8">-->
                        <!--    <h3 class="text-lg font-semibold mb-3 bg-primary-one-dark text-white py-2 px-5"><i class="fa fa-search mr-2"></i>Search</h3>-->
                        <!--    <form class="form-inline" method="GET" action="">-->
                        <!--        <input class="form-control mr-sm-2" type="search" name="query" placeholder="Search" aria-label="Search">-->
                        <!--        <button class=" btn-primary fa fa-search mt-3" type="submit"></button>-->
                        <!--        </form>-->
                        <!--</div>-->
                        
                        <div class="side-panel relative mb-8">
                            <h3 class="text-lg font-semibold mb-3  bg-primary-one-dark text-white py-2 px-5"><i class="fa fa-file-text mr-2"></i>Recent Posts</h3>
                            @if (count($blogs) > 0)
                                @foreach ($blogs as $blog)
                                <div class="recent-blogs">
                                    <ul class="list-unstyled m-0 blog-listing">
                                        <li class="py-2"><a href="{{ route('blogs.show', $blog->slug) }}"> {{ $blog->title }}</a></li>
                                    </ul>
                                </div>
                                @endforeach
                            @else
                            <div class="recent-blogs">
                                <p>No blogs found</p>
                            </div>
                            @endif
                        </div>
                        <div class="side-panel relative mb-8">
                            <h3 class="text-lg font-semibold mb-3  bg-primary-one-dark text-white py-2 px-5"><i class="fa fa-folder-open mr-2"></i>Categories</h3>
                            @foreach ($categories as $category)
                                <div class="recent-blogs">
                                    <ul class="list-unstyled m-0 blog-listing">
                                        <li class="py-2"><a href="{{ route('blogs.category', $category->slug) }}"> {{ $category->name }}</a></li>
                                    </ul>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

@endsection